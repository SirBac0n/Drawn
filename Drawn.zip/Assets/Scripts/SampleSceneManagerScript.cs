using UnityEngine;

public class SampleSceneManagerScript : MonoBehaviour
{
    public GameObject _enemyPrefab;
    public float spawnInterval;
    private float _lastSpawnTime;
    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        SpawnEnemy();
        _lastSpawnTime = Time.time;
    }

    // Update is called once per frame
    void Update()
    {
        if (Time.time > _lastSpawnTime + spawnInterval)
        {
            SpawnEnemy();
            _lastSpawnTime = Time.time;
        }
    }

    private void SpawnEnemy()
    {
        if (Random.value > 0.5f)
        {
            Instantiate(_enemyPrefab, new Vector3(-8, Random.Range(-3, 3), 0), Quaternion.identity);
        }
        else
        {
            Instantiate(_enemyPrefab, new Vector3(8, Random.Range(-3, 3), 0), Quaternion.identity);
        }

    }
}
