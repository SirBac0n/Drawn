using TMPro;
using UnityEngine;

public class SampleSceneManagerScript : MonoBehaviour
{
    public GameObject _enemyPrefab;
    public TMP_Text _scoreText;
    public TMP_Text _gameOverText;
    public float spawnInterval;
    private float _lastSpawnTime;
    private int _score;
    private bool _isGameOver;
    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        SpawnEnemy();
        _lastSpawnTime = Time.time;
        _score = 0;
        _scoreText.text = $"Score: {_score}";
        _isGameOver = false;
    }

    // Update is called once per frame
    void Update()
    {
        if (_isGameOver) return;
        if (Time.time > _lastSpawnTime + spawnInterval)
        {
            SpawnEnemy();
            _lastSpawnTime = Time.time;
        }
    }

    private void SpawnEnemy()
    {
        if (Random.value > 0.5f)
        {
            Instantiate(_enemyPrefab, new Vector3(-8, Random.Range(-3, 3), 0), Quaternion.identity);
        }
        else
        {
            Instantiate(_enemyPrefab, new Vector3(8, Random.Range(-3, 3), 0), Quaternion.identity);
        }

    }

    public void HitEnemy()
    {
        _score++;
        _scoreText.text = $"Score: {_score}";
    }

    public void GameOver()
    {
        _isGameOver = true;
        _scoreText.text = $"Final Score: {_score}";
        _gameOverText.gameObject.SetActive(true);
    }

    public bool IsGameOver() => _isGameOver;
}
