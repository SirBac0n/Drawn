using TMPro;
using UnityEngine;

public class SampleSceneManagerScript : MonoBehaviour
{
    public GameObject _enemyPrefab1;
    public GameObject _enemyPrefab2;
    public TMP_Text _scoreText;
    public TMP_Text _gameOverText;
    public float spawnInterval;
    private float runTime;
    private float _lastSpawnTime;
    private int _score;
    private bool _isGameOver;
    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        SpawnEnemy();
        _lastSpawnTime = Time.time;
        _score = 0;
        _scoreText.text = $"Score: {_score}";
        _isGameOver = false;
    }

    // Update is called once per frame
    void Update()
    {
        if (_isGameOver) return;
        if (Time.time > _lastSpawnTime + spawnInterval)
        {
            int numSpawn = Random.Range(1, 3);
            for (int i = 0; i < numSpawn; i++)
            {
                SpawnEnemy();
            }
            _lastSpawnTime = Time.time;
        }
        runTime = Time.time;
    }

    private void SpawnEnemy()
    {
        GameObject enemy = _enemyPrefab1;
        GameObject spawnedEnemy;
        if (Random.value > 0.66f)
        {
            enemy = _enemyPrefab2;
        }
        if (Random.value > 0.5f)
        {
            spawnedEnemy = Instantiate(enemy, new Vector3(-12, Random.Range(-3, 3), 0), Quaternion.identity);
        }
        else
        {
            spawnedEnemy =  Instantiate(enemy, new Vector3(12, Random.Range(-3, 3), 0), Quaternion.identity);
        }
        if (enemy == _enemyPrefab1)
        {
            EnemyScript enemyScript = spawnedEnemy.GetComponent<EnemyScript>();
            enemyScript.speed = Mathf.Min(runTime/15f + 1, 3);
        } else
        {
            RangedEnemyScript enemyScript = spawnedEnemy.GetComponent<RangedEnemyScript>();
            enemyScript.rockSpeed = Mathf.Min(runTime / 15f + 3, 5);
        }
    }

    public void HitEnemy()
    {
        _score++;
        _scoreText.text = $"Score: {_score}";
    }

    public void GameOver()
    {
        _isGameOver = true;
        _scoreText.text = $"Final Score: {_score}";
        _gameOverText.gameObject.SetActive(true);
    }

    public bool IsGameOver() => _isGameOver;
}
