using UnityEngine;

[RequireComponent(typeof(Rigidbody2D))]
public class EnemyScript : MonoBehaviour
{
    public float speed;
    private PlayerScript _player;
    private SampleSceneManagerScript _manager;
    private Rigidbody2D _rbody;
    private Vector2 _moveDirection;
    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        _player = FindAnyObjectByType<PlayerScript>();
        _manager = FindAnyObjectByType<SampleSceneManagerScript>();
        _moveDirection = (_player.transform.position - transform.position).normalized;
        _rbody = GetComponent<Rigidbody2D>();
    }

    // Update is called once per frame
    void Update()
    {
        if (_manager.IsGameOver()) return;
        _moveDirection = (_player.transform.position - transform.position).normalized;
    }
    void FixedUpdate()
    {
        if (_manager.IsGameOver())
        {
            _rbody.linearVelocity = Vector2.zero;
            return;
        }
        _rbody.linearVelocity = _moveDirection * speed;
    }

    private void OnCollisionEnter2D(Collision2D collision)
    {
        if (collision.gameObject.CompareTag("Arrow"))
        {
            _manager.HitEnemy();
            Destroy(gameObject);
        }
        if (collision.gameObject.CompareTag("Player"))
        {
            _manager.GameOver();
        }
    }
}

