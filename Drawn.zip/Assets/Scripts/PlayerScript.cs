using UnityEngine;
using UnityEngine.InputSystem;

[RequireComponent(typeof(Rigidbody2D))]
public class PlayerScript : MonoBehaviour
{
    public GameObject _arrowPrefab;
    public float moveSpeed;
    public float arrowSpeed;
    public float shootCooldown;
    Rigidbody2D _rbody;
    private SampleSceneManagerScript _manager;
    Vector2 _moveDirection;
    Vector2 _shootDirection;
    private float? _lastShootTime;
    SpriteRenderer _spriteRenderer;
    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        _rbody = GetComponent<Rigidbody2D>();
        _moveDirection = Vector2.zero;
        _shootDirection = new Vector2(1.1f, 0);
        _lastShootTime = null;
        _manager = FindAnyObjectByType<SampleSceneManagerScript>();
        _spriteRenderer = GetComponent<SpriteRenderer>();
    }

    // Update is called once per frame
    void Update()
    {
    }

    void FixedUpdate()
    {
        if (_manager.IsGameOver())
        {
            _rbody.linearVelocity = Vector2.zero;
            return;
        }
        _rbody.linearVelocity = _moveDirection * moveSpeed;
        if (_moveDirection.x < 0)
        {
            _shootDirection = new Vector2(-1.1f, 0);
            _spriteRenderer.flipX = false;
            
        }
        else if (_moveDirection.x > 0)
        {
            _shootDirection = new Vector2(1.1f, 0);
            _spriteRenderer.flipX = true;
        }
    }

    void OnMove(InputValue value)
    {
        if (_manager.IsGameOver()) return;
        Vector2 moveVec = value.Get<Vector2>();
        _moveDirection = moveVec;
    }

    void OnShoot()
    {
        if (_manager.IsGameOver()) return;
        Shoot(transform, _shootDirection);
    }

    public void Shoot(Transform shootPoint, Vector3 direction)
    {
        if (Time.time < _lastShootTime + shootCooldown) return;
        GameObject arrow = Instantiate(_arrowPrefab, shootPoint.position + direction, shootPoint.rotation);
        Rigidbody2D arrowRbody = arrow.GetComponent<Rigidbody2D>();
        SpriteRenderer arrowRender = arrow.GetComponent<SpriteRenderer>();
        arrowRbody.linearVelocity = direction * arrowSpeed;
        arrowRender.flipX = (direction.x > 0);
        _lastShootTime = Time.time;
    }

    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.gameObject.CompareTag("Rock"))
        {
            _manager.GameOver();
        }
    }
}
