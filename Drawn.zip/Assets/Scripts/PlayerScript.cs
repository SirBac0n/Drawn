using UnityEngine;
using UnityEngine.InputSystem;

[RequireComponent(typeof(Rigidbody2D))]
public class PlayerScript : MonoBehaviour
{
    public GameObject _arrowPrefab;
    public float moveSpeed;
    public float arrowSpeed;
    public float shootCooldown;
    Rigidbody2D _rbody;
    Vector2 _moveDirection;
    Vector2 _shootDirection;
    private float? _lastShootTime;
    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        _rbody = GetComponent<Rigidbody2D>();
        _moveDirection = Vector2.zero;
        _shootDirection = Vector2.right;
        _lastShootTime = null;
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    void FixedUpdate()
    {
        _rbody.linearVelocity = _moveDirection * moveSpeed;
        if (_moveDirection.x < 0)
        {
            _shootDirection = Vector2.left + new Vector2(-.1f, 0);
        }
        else if (_moveDirection.x > 0)
        {
            _shootDirection = Vector2.right + new Vector2(.1f, 0);
        }
    }

    void OnMove(InputValue value)
    {
        Vector2 moveVec = value.Get<Vector2>();
        _moveDirection = moveVec;
    }

    void OnShoot()
    {
        Debug.Log("Pew Pew");
        Shoot(transform, _shootDirection);
    }

    public void Shoot(Transform shootPoint, Vector3 direction)
    {
        if (Time.time < _lastShootTime + shootCooldown) return;
        GameObject arrow = Instantiate(_arrowPrefab, shootPoint.position + direction, shootPoint.rotation);
        Rigidbody2D arrowRbody = arrow.GetComponent<Rigidbody2D>();
        arrowRbody.linearVelocity = direction * arrowSpeed;
        _lastShootTime = Time.time;
    }

}
