using UnityEngine;

public class RangedEnemyScript : MonoBehaviour
{
    public float speed;
    private PlayerScript _player;
    private SampleSceneManagerScript _manager;
    private Rigidbody2D _rbody;
    private Vector2 _moveDirection;
    SpriteRenderer _spriteRenderer;
    private float lastThrowTime;
    private float throwInterval;
    public GameObject _rockPrefab;
    public float rockSpeed;

    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        _player = FindAnyObjectByType<PlayerScript>();
        _manager = FindAnyObjectByType<SampleSceneManagerScript>();
        _moveDirection = (_player.transform.position - transform.position).normalized;
        _rbody = GetComponent<Rigidbody2D>();
        _spriteRenderer = GetComponent<SpriteRenderer>();
        lastThrowTime = Time.time;
        throwInterval = 2.0f;
    }

    // Update is called once per frame
    void Update()
    {
        if (_manager.IsGameOver()) return;
        _moveDirection = (_player.transform.position - transform.position).normalized;
        _spriteRenderer.flipX = !(_moveDirection.x > 0);

    }
    void FixedUpdate()
    {
        if (_manager.IsGameOver())
        {
            _rbody.linearVelocity = Vector2.zero;
            return;
        }
        _rbody.linearVelocity = _moveDirection * speed;
        if ((_player.transform.position - transform.position).magnitude < 4)
        {
            _rbody.linearVelocityX = 0;
        }
        if (Time.time - lastThrowTime > throwInterval)
        {
            lastThrowTime = Time.time;
            GameObject rock = Instantiate(_rockPrefab, transform.position + (Vector3)_moveDirection, Quaternion.identity);
            Rigidbody2D rockRbody = rock.GetComponent<Rigidbody2D>();
            SpriteRenderer rockRender = rock.GetComponent<SpriteRenderer>();
            rockRbody.linearVelocityX = ((_moveDirection.x > 0) ? rockSpeed : -rockSpeed);
            rockRender.flipX = (_moveDirection.x > 0);
            throwInterval = Random.Range(2.0f, 4.0f);
        }
        transform.rotation = Quaternion.identity;
    }

    private void OnCollisionEnter2D(Collision2D collision)
    {
        if (collision.gameObject.CompareTag("Arrow"))
        {
            _manager.HitEnemy();
            Destroy(gameObject);
        }
    }
}
